package com.pens.catatanharian;

public class Constants {

    final static String direktoriFile = "/kominfo.proyek1";
}
